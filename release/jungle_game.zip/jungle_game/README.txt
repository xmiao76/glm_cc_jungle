Jungle (Dou Shou Qi) - Windows Desktop Game  v1.2
=================================================

DESCRIPTION
Jungle (also known as Dou Shou Qi or Animal Chess) is a traditional Chinese
strategy board game. Two players compete to either move a piece into the
opponent's den or capture all of the opponent's pieces. This release ships a
rebuilt, stronger AI engine.

SYSTEM REQUIREMENTS
- Windows 10 or later
- No installation required

HOW TO LAUNCH
Double-click jungle_game.exe to start the game.

If Windows Defender or your antivirus quarantines the file, you may need to
add an exception for the jungle_game folder. This is a common issue with
PyInstaller-packaged applications.

GAMEPLAY
You play as Blue (top of the board). The AI plays as Red (bottom).
By default you (Human/Blue) move first. Use the "Human First/AI First" button
to let the AI move first instead. Click one of your pieces to select it, then
click a highlighted target square to move there.

CONTROLS
- Left click: Select piece / Move to target
- ESC: Quit the game
- F: Flip the board view (does not change game state or turn order)
- "Human First/AI First" button: Toggle who moves first (applies to next game)
- "New Game" button: Start a new Human vs AI game
- "AI vs AI" button: Watch the AI play against itself
- "Flip Board" button: Flip the board view

PIECE RANKS (strongest to weakest)
 8. Elephant     - Can capture any piece except Rat
 7. Lion         - Can jump across the river (vertical + horizontal)
 6. Tiger        - Can jump across the river (vertical only)
 5. Leopard
 4. Wolf
 3. Dog
 2. Cat
 1. Rat          - Can capture Elephant (from land only); can enter water

CAPTURE RULES
- Higher rank captures lower rank
- Same rank captures each other
- Special: Rat can capture Elephant (but only from land, not from water)
- Special: Elephant cannot capture Rat under any circumstance

SPECIAL TERRAIN
- Water (blue): Only the Rat can enter. Lion and Tiger can jump across
  (blocked if any Rat is in the intervening water squares).
- Traps (player-tinted squares with X): A piece in the opponent's trap becomes
  rank 0 and can be captured by any enemy piece. Effect ends when leaving.
  Blue's traps are blue-tinted; Red's traps are red-tinted.
- Den (player-colored squares with star and "B"/"R" label): Move any piece into
  the opponent's den to win. You cannot enter your own den.

WIN CONDITIONS
- Move any piece into the opponent's den (Den Entry), OR
- Capture all of the opponent's pieces (Elimination)
- If a player has no legal moves, they lose (Stalemate)

AI VS AI MODE
Click "AI vs AI" to watch the computer play against itself. Both sides use the
same search AI. Note: two equal-strength AIs often play long, drawish games
(neither makes a losing mistake), so this mode is mainly for observing strategy.

AI ENGINE NOTES (v1.2)
The AI uses an iterative-deepening negamax search with alpha-beta / Principal
Variation Search, null-move pruning, late move reductions, killer moves and a
history heuristic, a two-bucket transposition table with incremental Zobrist
hashing, and a clean time-abort that only commits fully-searched iterations.
The evaluation is symmetric (required by negamax) and combines material,
den-attack advancement, den defense, trap handling, capture threats, mobility,
and endgame knowledge.

Performance changes in v1.2:
- Incremental Zobrist hashing (O(1) per move instead of recomputing) and a
  short-circuit win check, so the engine searches more positions per second
  (~11% more nodes at the default 1.5s/move budget) and reaches deeper in
  long searches.
- A critical bug from v1.1 was fixed: on timeout the AI could commit a
  partially-searched "garbage" move. It now discards interrupted iterations.
- Piece-square tables and den-threat search extensions were implemented and
  tested but are disabled by default (self-play measured them slightly
  harmful at the default time control); the simpler, stronger configuration
  ships.

Rules fix in v1.2:
- Fixed a trap-capture defect: a piece's effective rank for a capture is now
  based on its current (pre-move) position, so a higher-rank piece CAN capture a
  lower-rank piece sitting in the defender's own trap. (Previously the attacker
  was wrongly treated as rank 0 when moving onto the opponent's trap, which
  shielded the opponent's own pieces.) The opponent's trap still weakens enemy
  pieces that stand in it (they become rank 0 and capturable by any piece).

The AI thinks for about 1.5 seconds per move in Human-vs-AI mode.

RULES REFERENCE
Full rules: https://en.wikipedia.org/wiki/Jungle_(board_game)

TECHNICAL NOTES / MODEL & CODE AGENT
This game was developed and enhanced with Claude Code (claude.ai/code).
- Original application (v1.1): built with Claude Code powered by the GLM-5.1
  model.
- AI engine enhancement (v1.2): rebuilt and strengthened with Claude Code
  powered by the GLM-5.2 model (negamax + PVS rewrite, symmetric evaluation,
  the time-abort bug fix, incremental Zobrist hashing, and the faster win
  check).
The engine is pure Python (no external AI dependencies); the GUI is Pygame.
Source code, tests, and the packaging spec are in the project repository.